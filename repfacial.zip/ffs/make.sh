#!/bin/sh

${CC} -I. functionfs.c -lpthread -o ffs
